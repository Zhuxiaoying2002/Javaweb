package cn.edu.swu.ws.student;

public interface IStudentVisitor {
	public void visit(Student student);
}
